import React from "react"
import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";

import "./globals.css";

const _inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "BladeAddons — Hypixel SkyBlock Mod | Dungeon Mod for Minecraft 1.21",
  description:
    "Download BladeAddons, a free Hypixel SkyBlock mod for Minecraft 1.21. Dungeon route helpers, secret waypoints, party finder tweaks, and QoL features. Safe, lightweight Fabric mod.",
  keywords: [
    "hypixel skyblock mod",
    "hypixel skyblock dungeon mod",
    "skyblock mod",
    "minecraft skyblock mod",
    "hypixel dungeon mod",
    "bladeaddons",
    "skyblock fabric mod",
    "skyblock qol mod",
    "hypixel skyblock 1.21",
    "minecraft 1.21 mod",
    "skyblock dungeon helper",
    "skyblock secret waypoints",
    "hypixel mod download",
    "skyblock mod download",
    "fabric skyblock mod",
  ],
  openGraph: {
    title: "BladeAddons — Hypixel SkyBlock Mod",
    description:
      "Free Hypixel SkyBlock mod with dungeon helpers, secret waypoints, and QoL features. Available for Minecraft 1.21.8 and 1.21.5.",
    type: "website",
    siteName: "BladeAddons",
  },
  twitter: {
    card: "summary_large_image",
    title: "BladeAddons — Hypixel SkyBlock Mod",
    description:
      "Free Hypixel SkyBlock mod with dungeon helpers, secret waypoints, and QoL features for Minecraft 1.21.",
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: "/",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0a0f",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
