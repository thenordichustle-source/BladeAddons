import { Navbar } from "@/components/navbar";
import { Hero } from "@/components/hero";
import { Features } from "@/components/features";
import { DownloadSection } from "@/components/download";
import { Footer } from "@/components/footer";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "BladeAddons",
  applicationCategory: "GameApplication",
  operatingSystem: "Windows, macOS, Linux",
  description:
    "A free Hypixel SkyBlock mod for Minecraft 1.21 with dungeon route helpers, secret waypoints, party finder tweaks, and quality-of-life features. Safe, lightweight Fabric mod.",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  softwareRequirements: "Minecraft 1.21.5 or 1.21.8 with Fabric Loader",
  applicationSubCategory: "Minecraft Mod",
  keywords:
    "hypixel skyblock mod, hypixel skyblock dungeon mod, skyblock mod, minecraft skyblock mod, bladeaddons, fabric skyblock mod",
};

export default function Page() {
  return (
    <>
      <script
        type="application/ld+json"
        // biome-ignore lint: safe structured data
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <Navbar />
      <main>
        <Hero />
        <Features />
        <DownloadSection />
      </main>
      <Footer />
    </>
  );
}
