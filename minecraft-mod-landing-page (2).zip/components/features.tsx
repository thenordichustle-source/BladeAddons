"use client";

import { useEffect, useRef } from "react";
import { Zap, Eye, BarChart3, Shield, Settings, Layers } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Dungeon Optimized",
    description:
      "Plenty of mods that enhance your dungeon grinds. Route helpers, secret waypoints, and party finder tweaks all baked in.",
    glowClass: "glow-border-green",
    iconBg: "bg-[hsl(142_70%_50%/0.1)]",
    iconColor: "text-[hsl(142_70%_50%)]",
  },
  {
    icon: Eye,
    title: "Smooth Integration",
    description:
      "Runs alongside your existing Fabric mods without conflicts. Drop it in your mods folder and everything just works.",
    glowClass: "glow-border-purple",
    iconBg: "bg-[hsl(270_70%_60%/0.1)]",
    iconColor: "text-[hsl(270_70%_60%)]",
  },
  {
    icon: Shield,
    title: "Not Bannable",
    description:
      "Not a cheating mod. BladeAddons follows Hypixel's mod guidelines and only provides QoL features that keep your account safe.",
    glowClass: "glow-border-cyan",
    iconBg: "bg-[hsl(190_90%_55%/0.1)]",
    iconColor: "text-[hsl(190_90%_55%)]",
  },
  {
    icon: BarChart3,
    title: "Built for Performance",
    description:
      "Lightweight and optimized for Fabric. Minimal memory footprint so your FPS stays high even during Goldor phase.",
    glowClass: "glow-border-green",
    iconBg: "bg-[hsl(142_70%_50%/0.1)]",
    iconColor: "text-[hsl(142_70%_50%)]",
  },
  {
    icon: Settings,
    title: "Fully Configurable",
    description:
      "Every module can be toggled and tuned from the in-game config. Set it up once and forget about it.",
    glowClass: "glow-border-purple",
    iconBg: "bg-[hsl(270_70%_60%/0.1)]",
    iconColor: "text-[hsl(270_70%_60%)]",
  },
  {
    icon: Layers,
    title: "Community Driven",
    description:
      "Built by players, for players. Feedback shapes every update and the source stays transparent so you know exactly what you're running.",
    glowClass: "glow-border-cyan",
    iconBg: "bg-[hsl(190_90%_55%/0.1)]",
    iconColor: "text-[hsl(190_90%_55%)]",
  },
];

export function Features() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll("[data-animate]");
            cards.forEach((card, i) => {
              setTimeout(() => {
                (card as HTMLElement).style.opacity = "1";
                (card as HTMLElement).style.transform = "translateY(0)";
              }, i * 100);
            });
            observer.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="features"
      ref={sectionRef}
      className="mx-auto max-w-5xl px-6 py-24"
    >
      <div className="mb-16 text-center">
        <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Everything you need for Hypixel SkyBlock
        </h2>
        <p className="mt-4 text-lg text-muted-foreground">
          A complete Minecraft mod toolkit built for serious SkyBlock and dungeon players.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => (
          <div
            key={feature.title}
            data-animate
            className={`rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:${feature.glowClass} ${feature.glowClass}`}
            style={{
              opacity: 0,
              transform: "translateY(20px)",
              transition:
                "opacity 0.5s ease, transform 0.5s ease, box-shadow 0.3s ease",
            }}
          >
            <div
              className={`mb-4 flex h-10 w-10 items-center justify-center rounded-xl ${feature.iconBg}`}
            >
              <feature.icon className={`h-5 w-5 ${feature.iconColor}`} />
            </div>
            <h3 className="text-lg font-semibold text-card-foreground">
              {feature.title}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {feature.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
