"use client";

import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 z-50 w-full transition-all duration-300",
        scrolled
          ? "border-b border-border bg-background/80 backdrop-blur-md"
          : "bg-transparent"
      )}
    >
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <a href="#" className="flex items-center gap-2 text-foreground">
          <svg
            width="24"
            height="24"
            viewBox="0 0 32 32"
            fill="none"
            aria-hidden="true"
          >
            <rect x="4" y="4" width="10" height="10" rx="2" fill="hsl(142 70% 50%)" opacity="0.9" />
            <rect x="18" y="4" width="10" height="10" rx="2" fill="hsl(270 70% 60%)" opacity="0.7" />
            <rect x="4" y="18" width="10" height="10" rx="2" fill="hsl(190 90% 55%)" opacity="0.7" />
            <rect x="18" y="18" width="10" height="10" rx="2" fill="hsl(38 90% 55%)" opacity="0.5" />
          </svg>
          <span className="text-lg font-semibold">BladeAddons</span>
        </a>

        <div className="hidden items-center gap-8 sm:flex">
          <a
            href="#features"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Features
          </a>
          <a
            href="#download"
            className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            Download
          </a>
        </div>

        <a
          href="#download"
          className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 sm:hidden"
        >
          Download
        </a>
      </nav>
    </header>
  );
}
