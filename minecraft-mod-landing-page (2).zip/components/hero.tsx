"use client";

import { ChevronDown } from "lucide-react";
import { useEffect, useState } from "react";

export function Hero() {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    // Stage 0: nothing visible
    // Stage 1: BLADE fades in (after 200ms)
    // Stage 2: Addons subtitle + glow expand (after 1400ms)
    // Stage 3: description + CTA (after 2200ms)
    const t1 = setTimeout(() => setStage(1), 200);
    const t2 = setTimeout(() => setStage(2), 1400);
    const t3 = setTimeout(() => setStage(3), 2200);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  return (
    <section
      aria-label="BladeAddons — Hypixel SkyBlock Mod for Minecraft 1.21"
      className="relative flex min-h-[100vh] flex-col items-center justify-center overflow-hidden px-6 text-center"
    >
      {/* Animated background glow orbs */}
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-[2000ms] ease-out"
        style={{
          opacity: stage >= 1 ? 1 : 0,
          transform: `translate(-50%, -50%) scale(${stage >= 2 ? 1 : 0.4})`,
        }}
        aria-hidden="true"
      >
        <div className="h-[700px] w-[700px] rounded-full bg-[hsl(142_70%_50%/0.06)] blur-[140px]" />
      </div>
      <div
        className="pointer-events-none absolute left-1/4 top-1/3 -translate-x-1/2 -translate-y-1/2 transition-all duration-[2500ms] ease-out"
        style={{
          opacity: stage >= 2 ? 1 : 0,
          transform: `translate(-50%, -50%) scale(${stage >= 2 ? 1 : 0.3})`,
        }}
        aria-hidden="true"
      >
        <div className="h-[350px] w-[350px] rounded-full bg-[hsl(270_70%_60%/0.07)] blur-[100px]" />
      </div>
      <div
        className="pointer-events-none absolute right-1/4 top-2/3 translate-x-1/2 -translate-y-1/2 transition-all duration-[2500ms] ease-out"
        style={{
          opacity: stage >= 2 ? 1 : 0,
          transform: `translateX(50%) translateY(-50%) scale(${stage >= 2 ? 1 : 0.3})`,
        }}
        aria-hidden="true"
      >
        <div className="h-[280px] w-[280px] rounded-full bg-[hsl(190_90%_55%/0.05)] blur-[90px]" />
      </div>

      <div className="relative z-10 flex flex-col items-center">
        {/* ODIN - Stage 1: dramatic scale-up fade-in */}
        <h1
          className="text-7xl font-black tracking-tighter transition-all duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] sm:text-8xl md:text-9xl lg:text-[10rem]"
          style={{
            opacity: stage >= 1 ? 1 : 0,
            transform: `translateY(${stage >= 1 ? "0px" : "30px"}) scale(${stage >= 1 ? 1 : 0.9})`,
            letterSpacing: stage >= 2 ? "-0.04em" : "-0.02em",
          }}
        >
          <span
            className="inline-block bg-clip-text text-transparent transition-all duration-[1500ms] ease-out"
            style={{
              backgroundImage:
                stage >= 2
                  ? "linear-gradient(135deg, hsl(142 70% 50%), hsl(190 90% 55%), hsl(270 70% 60%))"
                  : "linear-gradient(135deg, hsl(142 70% 50%), hsl(142 70% 60%))",
              filter:
                stage >= 2
                  ? "drop-shadow(0 0 30px hsl(142 70% 50% / 0.4)) drop-shadow(0 0 60px hsl(270 70% 60% / 0.2))"
                  : "drop-shadow(0 0 20px hsl(142 70% 50% / 0.3))",
            }}
          >
            BLADE
          </span>
        </h1>

        {/* Subtitle - Stage 2: slides up with stagger */}
        <div
          className="mt-3 flex items-center gap-2 transition-all duration-[1000ms] ease-[cubic-bezier(0.16,1,0.3,1)] sm:gap-3"
          style={{
            opacity: stage >= 2 ? 1 : 0,
            transform: `translateY(${stage >= 2 ? "0px" : "20px"})`,
          }}
        >
          <div className="h-px w-8 bg-gradient-to-r from-transparent to-[hsl(142_70%_50%/0.5)] sm:w-12" />
          <p className="text-sm font-medium uppercase tracking-[0.25em] text-muted-foreground sm:text-base md:text-lg">
            <span className="text-[hsl(270_70%_60%)]">Addons</span>
          </p>
          <div className="h-px w-8 bg-gradient-to-l from-transparent to-[hsl(270_70%_60%/0.5)] sm:w-12" />
        </div>

        {/* Thin glowing divider */}
        <div
          className="mt-8 h-px w-32 transition-all duration-[1200ms] ease-out sm:w-48"
          style={{
            opacity: stage >= 2 ? 1 : 0,
            transform: `scaleX(${stage >= 2 ? 1 : 0})`,
            background:
              "linear-gradient(90deg, transparent, hsl(142 70% 50% / 0.4), hsl(270 70% 60% / 0.4), transparent)",
          }}
        />

        {/* Description - Stage 3 */}
        <p
          className="mt-8 max-w-md text-pretty text-base leading-relaxed text-muted-foreground transition-all duration-[1000ms] ease-[cubic-bezier(0.16,1,0.3,1)] sm:text-lg md:max-w-lg md:text-xl"
          style={{
            opacity: stage >= 3 ? 1 : 0,
            transform: `translateY(${stage >= 3 ? "0px" : "16px"})`,
          }}
        >
          Enhance your Hypixel SkyBlock experience with powerful dungeon tools and
          quality-of-life improvements. Download this free SkyBlock mod for Minecraft 1.21.8 and 1.21.5.
        </p>

        {/* CTA - Stage 3 with slight delay via CSS */}
        <a
          href="#features"
          className="mt-14 flex flex-col items-center gap-2 text-sm font-medium text-muted-foreground transition-all duration-[1000ms] ease-[cubic-bezier(0.16,1,0.3,1)] hover:text-foreground"
          style={{
            opacity: stage >= 3 ? 1 : 0,
            transform: `translateY(${stage >= 3 ? "0px" : "12px"})`,
            transitionDelay: stage >= 3 ? "200ms" : "0ms",
          }}
        >
          <span>Scroll to explore</span>
          <ChevronDown className="h-5 w-5 animate-bounce" />
        </a>
      </div>
    </section>
  );
}
