"use client";

import { useEffect, useRef } from "react";
import { Download, FileBox } from "lucide-react";
import { Button } from "@/components/ui/button";

const glowCycle = [
  {
    glowClass: "glow-border-green",
    iconBg: "bg-[hsl(142_70%_50%/0.1)]",
    iconColor: "text-[hsl(142_70%_50%)]",
  },
  {
    glowClass: "glow-border-purple",
    iconBg: "bg-[hsl(270_70%_60%/0.1)]",
    iconColor: "text-[hsl(270_70%_60%)]",
  },
  {
    glowClass: "glow-border-cyan",
    iconBg: "bg-[hsl(190_90%_55%/0.1)]",
    iconColor: "text-[hsl(190_90%_55%)]",
  },
];

const versions = [
  { mcVersion: "1.21.8", label: "Latest" },
  { mcVersion: "1.21.5", label: "Stable" },
] as const;

export function DownloadSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll("[data-animate]");
            cards.forEach((card, i) => {
              setTimeout(() => {
                (card as HTMLElement).style.opacity = "1";
                (card as HTMLElement).style.transform = "translateY(0)";
              }, i * 80);
            });
            observer.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="download"
      ref={sectionRef}
      className="relative mx-auto max-w-5xl px-6 py-24"
    >
      {/* Subtle glow behind section */}
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        aria-hidden="true"
      >
        <div className="h-[500px] w-[600px] rounded-full bg-[hsl(270_70%_60%/0.04)] blur-[120px]" />
      </div>

      <div className="relative z-10 mb-16 text-center">
        <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Download BladeAddons for Minecraft 1.21
        </h2>
        <p className="mt-4 text-lg text-muted-foreground">
          Pick your Minecraft version. Drop the{" "}
          <code className="rounded bg-secondary px-1.5 py-0.5 text-sm font-mono text-[hsl(142_70%_50%)]">.jar</code>{" "}
          into your{" "}
          <code className="rounded bg-secondary px-1.5 py-0.5 text-sm font-mono text-[hsl(190_90%_55%)]">mods</code>{" "}
          folder and you're good to go.
        </p>
      </div>

      <div className="relative z-10 mx-auto grid max-w-2xl gap-6 sm:grid-cols-2">
        {versions.map((version, i) => {
          const style = glowCycle[i % glowCycle.length];
          const fileName = `bladeaddons-${version.mcVersion}.jar`;
          const isLatest = "label" in version && version.label === "Latest";

          return (
            <div
              key={version.mcVersion}
              data-animate
              className={`flex flex-col rounded-2xl border border-border bg-card p-6 transition-all duration-300 ${style.glowClass} ${isLatest ? "ring-1 ring-[hsl(142_70%_50%/0.25)]" : ""}`}
              style={{
                opacity: 0,
                transform: "translateY(20px)",
                transition:
                  "opacity 0.5s ease, transform 0.5s ease, box-shadow 0.3s ease",
              }}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${style.iconBg}`}
                >
                  <FileBox className={`h-5 w-5 ${style.iconColor}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-card-foreground">
                      {version.mcVersion}
                    </h3>
                    {"label" in version && version.label && (
                      <span
                        className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${
                          version.label === "Latest"
                            ? "bg-[hsl(142_70%_50%/0.12)] text-[hsl(142_70%_50%)]"
                            : "bg-[hsl(190_90%_55%/0.12)] text-[hsl(190_90%_55%)]"
                        }`}
                      >
                        {version.label}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground font-mono truncate">
                    {fileName}
                  </p>
                </div>
              </div>

              <Button
                className="mt-4 w-full gap-2 rounded-xl text-sm"
                size="sm"
                asChild
              >
                <a href={`/downloads/${fileName}`} download aria-label={`Download BladeAddons Hypixel SkyBlock mod for Minecraft ${version.mcVersion}`}>
                  <Download className="h-4 w-4" />
                  Download
                </a>
              </Button>
            </div>
          );
        })}
      </div>
    </section>
  );
}
